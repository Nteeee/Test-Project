<?php
session_start();

@  $usr  = json_encode($_POST[username]);
@  $em  = json_encode($_POST[email]);
@  $pwd  = json_encode($_POST[password]);
@  $usr_type  = json_encode($_POST[user_type]);


$usr = str_replace('"', "", $usr);
$em = str_replace('"', "", $em);
$pwd = str_replace('"', "", $pwd);
$usr_type = str_replace('"', "", $usr_type);



$username = "";
$email    = "";

$errors = array(); 


$db = mysqli_connect('localhost', 'root', 'root#123', 'nthab');

  
  $username = mysqli_real_escape_string($db, trim($usr));
  $email = mysqli_real_escape_string($db, trim($em));
  $password = mysqli_real_escape_string($db, trim($pwd));
  $userType = mysqli_real_escape_string($db, trim($usr_type));
 

 
  if (empty($username)) { array_push($errors, "Username is required"); }
  if (empty($email)) { array_push($errors, "Email is required"); }
  if (empty($password)) { array_push($errors, "Password is required"); }


  if (isset($_POST['reg_user'])) {
  $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
  $result = mysqli_query($db, $user_check_query);
  $user = mysqli_fetch_assoc($result);

  if ($user) { // if user exists
    if ($user['username'] === $username) {
      array_push($errors, "Username already exists");
    }

    if ($user['email'] === $email) {
      array_push($errors, "email already exists");
    }
  }
}


  if (count($errors) == 0) {
  	$password = md5($password);

  	$query = "INSERT INTO users (username, email, password,type_id)VALUES('$username', '$email', '$password','$userType')";
    mysqli_query($db, $query);
    array_push($errors, "You are successfully registered");
  //	$_SESSION['username'] = $username;
  //	$_SESSION['success'] = "You are now logged in";
  	//header('location: index.php');
  }


if (isset($_POST['login_user'])) {
  $username = mysqli_real_escape_string($db, $_POST['username']);
  $password = mysqli_real_escape_string($db, $_POST['password']);

  if (empty($username)) {
  	array_push($errors, "Username is required");
  }
  if (empty($password)) {
  	array_push($errors, "Password is required");
  }

  if (count($errors) == 0) {
  	$password = md5($password);
  	$query = "SELECT * FROM users WHERE username='$username' AND password='$password'";
  	$results = mysqli_query($db, $query);
  	if (mysqli_num_rows($results) == 1) {
  	  $_SESSION['username'] = $username;
  	  $_SESSION['success'] = "You are now logged in";
  	  header('location: index.php');
  	}else {
  		array_push($errors, "Wrong username/password combination");
  	}
  }
}

?>

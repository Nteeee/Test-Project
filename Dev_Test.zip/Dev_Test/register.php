<?php include('server.php') ?>
<!DOCTYPE html>
<html>
<head>
  <title>test</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="bootstrap.css">
</head>
<body>
  <div class="header">
  	<h2>Register</h2>
  </div>
	
  <form id="userForm">
  	<?php include('errors.php'); ?>
  	<div class="input-group">
  	  <label>Username</label>
  	  <input type="text" name="username" >
  	</div>
  	<div class="input-group">
  	  <label>Email</label>
  	  <input type="email" name="email" >
  	</div>
  	<div class="input-group">
  	  <label>Password</label>
  	  <input type="password" name="password">
  	</div>
      <div class="input-group">
  	  <label>User Type</label>
  	  <select name="user_type">
				<option value="1">Sales</option>
				<option value="2">Operations</option>
			</select>
  	
		</div>
		
  	<div class="input-group">
  	  <button type="submit" class="btn" id="submit" name="reg_user">Register</button>
  	</div>
		
  	<p>
  		Already a member? <a href="login.php">Sign in</a>
  	</p>
		<div id='response'></div>
  </form>
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js "></script>
<script>
$(document).ready(function(){
    $('#userForm').submit(function(){
        $('#response').html("<b>Loading response...</b>");

        $.ajax({
            type: 'POST',
            url: 'server.php', 
            data: $(this).serialize()
        })
        .done(function(data){
            $('#response').html(data); 
        })
        .fail(function() {
            alert( "Posting failed." );  
        });
 
        
        return false;
 
    });
});
</script>
</body>
</html>
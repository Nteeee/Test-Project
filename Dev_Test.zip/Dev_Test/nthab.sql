-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2018 at 06:53 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nthab`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `type_id` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `email`, `type_id`) VALUES
(1, 'admin', '7bead9809844bde4f6cccb5cc5214f76', 'b@gmail.com', 0),
(2, 'black', 'ec9885202a0baf38e2c97bd8e73ec8fa', 'black@gmail.com', 2),
(3, 'b', '7bead9809844bde4f6cccb5cc5214f76', 'b@webmail.com', 2),
(4, 'n', '0154a613e855558bef10f88a18a91163', 'n@gmail.com', 2),
(5, 'sd', '0179cf165b9ae1fbf4f3bcaed5da42a9', 'fg@as.com', 2),
(6, 'ks', 'b9209564e98ea5b8f3e6270fe478a7ca', 'li@sdml.com', 2),
(7, '\"jab\"', '212a20419569c110cf60d5b3cc4e8e83', '\"jab@jb.com\"', 0),
(8, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(9, '\"ja\"', '8d4a5849839947fd0b676986a17fca6b', '\"ja@gk.com\"', 0),
(10, '\"ja\"', '8d4a5849839947fd0b676986a17fca6b', '\"ja@gk.com\"', 0),
(11, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(12, '\"black\"', '101a0bb1b73b7f46fb248179ff09f8f1', '\"black@gmail.com\"', 0),
(13, '\"black\"', '101a0bb1b73b7f46fb248179ff09f8f1', '\"black@gmail.com\"', 0),
(14, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(15, 'lkg', '6b97c5d7783133f3d70b781b69bfb07e', 'lgk@lgk.com', 2),
(16, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(17, 'lkg', '8d804a5c53b69a7342c5c3c7ddc5364d', 'lgk@lgk.com', 1),
(18, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(19, 'black', '8d804a5c53b69a7342c5c3c7ddc5364d', 'black@gmail.com', 2),
(20, 'black', '8d804a5c53b69a7342c5c3c7ddc5364d', 'black@gmail.com', 2),
(21, 'black', '8d804a5c53b69a7342c5c3c7ddc5364d', 'black@gmail.com', 2),
(22, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(23, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(24, 'null', '37a6259cc0c1dae299a7866489dff0bd', 'null', 0),
(25, 'm', '7078ffe90f5cb8e53e577cb3e7c366ac', 'm@m.com', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

CREATE TABLE `user_types` (
  `id` int(255) NOT NULL,
  `type_description` varchar(255) NOT NULL,
  `access_level` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_types`
--
ALTER TABLE `user_types`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_types`
--
ALTER TABLE `user_types`
  ADD CONSTRAINT `user_types_ibfk_1` FOREIGN KEY (`id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
